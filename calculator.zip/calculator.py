#python program for simple calculator
class Calculator:
    
    def __init__(self) -> None:
        print(" 1. Addition(+) \n 2. Subtraction(-) \n 3. Multiplication(*) \n 4. Division(/) \n 5. modulas(%)")
        print("select any option from 1,2,3,4,5 :")
        
    # Add function to add 2 numbers
    def Add(self):
        self.x = float(input(' enter first number: '))
        self.y = float(input(' enter second number: '))
        print(self.x,'+',self.y,'=',format(self.x+self.y,'.3f'))
        
    # sub function to subtract 2 numbers
    def sub(self):
        self.x = float(input(' enter first number: '))
        self.y = float(input(' enter second number: '))
        print(self.x,'-',self.y,'=',format(self.x-self.y,'.3f'))
        
    # multi function to multiply 2 numbers 
    def multi(self):
        self.x = float(input(' enter first number: '))
        self.y = float(input(' enter second number: '))
        print(self.x,'*',self.y,'=',format(self.x*self.y,'.3f'))
    
    # div function to divide 2 numbers
    def div(self):
        self.x = float(input(' enter first number: '))
        self.y = float(input(' enter second number: '))
        print(self.x,'/',self.y,'=',format(self.x/self.y,'.4f'))
    
    # mod function to calculate modulas
    def mod(self):
        self.x = int(input(' enter first number: '))
        self.y = int(input(' enter second number: '))
        print(self.x,'%',self.y,'=',self.x % self.y)
        
        
calci = Calculator()

# take input from the user
select = int(input())
if select == 1:
    calci.Add()
elif select == 2:
    calci.sub()
elif select == 3:
    calci.multi()
elif select == 4:
    calci.div()
elif select == 5:
    calci.mod()
else:
    print("invalid choice! ")


    




